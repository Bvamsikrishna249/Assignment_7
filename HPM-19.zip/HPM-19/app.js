const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
const { MongoClient } = require('mongodb');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 9988;
const MONGODB_URI = process.env.MONGODB_URI;

// Middleware to serve static files (CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// MongoDB connection setup
let db;
MongoClient.connect(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(client => {
    console.log('Connected to Database');
    db = client.db(); // Store database connection
  })
  .catch(err => {
    console.error('Failed to connect to the database', err);
    process.exit(1); // Exit the application if the DB connection fails
  });

// JWT functions
const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, username: user.username, usertype: user.usertype },
    process.env.JWT_SECRET,
    { expiresIn: '1h' } // Token expiration time
  );
};

// Middleware to protect routes
const authenticateJWT = (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1]; // Bearer token

  if (token) {
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
      if (err) {
        return res.sendStatus(403); // Forbidden
      }
      req.user = user; // Save user info to request object
      next();
    });
  } else {
    res.sendStatus(401); // Unauthorized
  }
};

// Routes
app.get('/', (req, res) => {
  res.render('index');
});

app.get('/registration', (req, res) => {
  res.render('registration');
});

app.get('/about', (req, res) => {
  res.render('about');
});

// User Registration
app.post('/register', async (req, res) => {
  const { username, password, usertype } = req.body;

  try {
    // Check if the username already exists
    const existingUser = await db.collection('login').findOne({ username });
    if (existingUser) {
      return res.status(400).send('Username already exists');
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = { username, password: hashedPassword, usertype };
    await db.collection('login').insertOne(newUser);
    res.status(201).send('User registered successfully');
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).send('Error registering user');
  }
});

// User Login
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await db.collection('login').findOne({ username });
    if (user && await bcrypt.compare(password, user.password)) {
      const token = generateToken(user); // Generate JWT
      res.json({ token }); // Send token to client
    } else {
      res.status(401).send('Invalid username or password');
    }
  } catch (error) {
    console.error('Server error during login:', error);
    res.status(500).send('Server error');
  }
});

// Protected route to fetch parking data
app.get('/api/parking', authenticateJWT, async (req, res) => {
  try {
    const parkingData = await db.collection('parking').find().toArray();
    res.json(parkingData); // Send parking data as JSON
  } catch (error) {
    console.error('Error fetching parking data:', error);
    res.status(500).send('Server error');
  }
});

// Route to fetch login data (for example purposes)
app.get('/login-data', authenticateJWT, async (req, res) => {
  try {
    const loginData = await db.collection('login').find().toArray();
    res.json(loginData); // Send login data as JSON
  } catch (error) {
    console.error('Error fetching login data:', error);
    res.status(500).send('Server error');
  }
});

// 404 Error handling
app.use((req, res) => {
  res.status(404).render('404', { message: 'Page not found' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
